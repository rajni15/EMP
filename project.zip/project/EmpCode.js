var eno=undefined;
var enm=undefined;
var job=undefined;
var sal=undefined;
var comm=undefined;
var bonus=undefined;
var tbody=undefined;
var empary=[];

function init(){
    eno=document.getElementById("eno");
    enm=document.getElementById("enm");
    job=document.getElementById("job");
    sal=document.getElementById("sal");
    comm=document.getElementById("comm");
    bonus=document.getElementById("bonus");
    tbody=document.getElementById("tbody");

    var mydata=localStorage.getItem("edata");
    // console.log(mydata)
    var earr=JSON.parse(mydata);
    // console.log(earr)
    for(var p of earr){
        empary.push(p);
        addData(p);
    }

}
function process(){
    var veno=eno.value;
    var venm=enm.value;
    var vjob=job.value;
    var vsal=parseInt(sal.value);
    var vcomm=parseInt(comm.value);
    var vbonus=parseInt(bonus.value);

    empobj={veno,venm,vjob,vsal,vcomm,vbonus}
    // console.log(empobj)
    empary.push(empobj);
    addData(empobj);
}

function save(){
    // console.log(empary);
    var empdata=JSON.stringify(empary);
    localStorage.setItem("edata",empdata);
    // console.log(empdata);

    // var myobj=JSON.parse(empdata);
    // console.log(myobj);
}


function addData(obj){
var tr=document.createElement("tr");

var td0=document.createElement("td");
td0.innerText=empary.length ;
tr.appendChild(td0);


var td1=document.createElement("td");
td1.innerText=obj.veno;
tr.appendChild(td1);

var td2=document.createElement("td");
td2.innerText=obj.venm;
tr.appendChild(td2);

var td3=document.createElement("td");
td3.innerText=obj.vjob;
tr.appendChild(td3);

var td4=document.createElement("td");
td4.innerText=obj.vsal;
tr.appendChild(td4);

var td5=document.createElement("td");
td5.innerText=obj.vcomm;
tr.appendChild(td5);

var td6=document.createElement("td");
td6.innerText=obj.vbonus;
tr.appendChild(td6);

var td7=document.createElement("td");
td7.innerText=obj.vsal+obj.vcomm+obj.vbonus;
tr.appendChild(td7);

var btns=document.createElement("button");
btns.innerText="Delete";
btns.setAttribute("class","btn-lg btn-danger");
btns.onclick=del;

var idx=empary.length-1;
btns.setAttribute("data-idx",idx);

var td9=document.createElement("td");
td9.appendChild(btns);
tr.appendChild(td9);

tbody.appendChild(tr);
}

function del(){
    // alert(this);
    var idx=this.getAttribute("data-idx");
    empary.splice(idx,1);
    // alert(idx);
    this.parentElement.parentElement.remove();
}